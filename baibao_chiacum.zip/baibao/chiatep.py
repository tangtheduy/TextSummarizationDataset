import os
import shutil

# Đường dẫn đến thư mục chứa các tệp văn bản của bạn
file_path = 'D:/đồ án tốt nghiệp/crawldata/baibao'

# Số lượng thư mục bạn muốn chia các tệp thành
num_folders = 10

# Tạo các thư mục con
for i in range(num_folders):
    folder_name = f'folder_{i}'
    os.makedirs(os.path.join(file_path, folder_name))

# Chia các tệp thành các thư mục con
for i in range(1, 10584):
    filename = f'baibao_{i}.txt'
    folder_idx = (i - 1) % num_folders
    folder_name = f'folder_{folder_idx}'
    shutil.move(os.path.join(file_path, filename), os.path.join(file_path, folder_name, filename))
